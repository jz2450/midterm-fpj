var socket;
var ghostyMicStream;
var myHostyPeer;
var isMuted = true;
var mystream;

// get turn servers
var turnServers = {};
(async () => {
  try {
    const response = await fetch("https://fpj.metered.live/api/v1/turn/credentials?apiKey=98bac8d8be959ecddea0203fe867c1da1b21");
    const iceServers = await response.json();
    turnServers = iceServers;
    console.log(turnServers);
  } catch (error) {
    console.error(error);
  }
})();

window.addEventListener("load", function () {
  enableEnterKey();

  initCapture();

  // socket.io things
  socket = io.connect();

  socket.on("connect", function () {
    console.log("Connected");
    socket.emit("fpjHostyGhostyCheck");
  });

  // catch if someone is connected already, if so, hide input fields and haunt button
  // and change text on screen
  socket.on("fpjNoHosty", function () {
    console.log("oops there's no hosty");
    let statusText = document.getElementById("statusText");
    statusText.innerHTML = "OFFLINE, please try again later";
    hideGhostyConnectOptions();
  });

  socket.on("fpjGhostyDoubleUp", function () {
    console.log("oops the hosty has a ghosty already");
    let statusText = document.getElementById("statusText");
    statusText.innerHTML =
      "ONLINE but already haunted :( please try again later";
    hideGhostyConnectOptions();
  });

  socket.on("fpjYesHosty", function () {
    console.log("hosty has come online! :)");
    let statusText = document.getElementById("statusText");
    statusText.innerHTML = "ONLINE and ready to be haunted";
    showGhostyConnectOptions();
  });

  socket.on("fpjGhostyConnected", function (data) {
    console.log("connected to hosty " + data);
    document.getElementById("ghostName").innerHTML = document.getElementById("ghostNameInput").value;
    myHostyPeer = new SimplePeerWrapper(false, data, socket, mystream);
    showGhostyUI();
  });

  socket.on('fpjHostyDisconnect', function (data) {
    unhaunt();
  });
});

// helper functions

function enableEnterKey() {
  let nameInput = document.getElementById("ghostNameInput");
  nameInput.addEventListener("keypress", function (event) {
    if (event.key === "Enter") {
      event.preventDefault();
      document.getElementById("hauntButton").click();
    }
  });
}

function initCapture() {
  console.log("initCapture");
  navigator.mediaDevices
    .getUserMedia({
      audio: true,
      video: false,
    })
    .then(function (stream) {
      mystream = stream;
    })
    .catch(function (err) {
      alert(err);
    });
}

function hauntHosty() {
  let ghostName = document.getElementById("ghostNameInput").value;
  if (ghostName.length > 0) {
    socket.emit("fpjGhostyConnect", ghostName);
  }
}

function unhaunt() {
  window.location.replace("/fpj/");
}

function hideGhostyConnectOptions() {
  let myelements = document.getElementsByClassName("onlyIfConnected");
  for (var i = 0; i < myelements.length; i++) {
    myelements.item(i).classList.add("hidden");
  }
}

function showGhostyConnectOptions() {
  let myelements = document.getElementsByClassName("onlyIfConnected");
  for (var i = 0; i < myelements.length; i++) {
    myelements.item(i).classList.remove("hidden");
  }
}

function showGhostyUI() {
  document.getElementById("loginScreen").classList.add("hidden");
  document.getElementById("main").classList.remove("hidden");
  initiateKeyboardControls();

  // handle more socket events
  socket.on("fpjNewInstruction", function (data) {
    console.log("new instruction: " + data);
    let displayText = document.getElementById("displayMessageText");
    let newDisplayText = displayText.cloneNode(true);
    newDisplayText.innerHTML = data;
    newDisplayText.style.animation = "instrFade 2s forwards";
    displayText.parentNode.replaceChild(newDisplayText, displayText);
  });

  socket.on("fpjSignal", function (to, from, data) {
    console.log("Got a signal from the server: ", to, from, data);
    if (myHostyPeer.socket_id == from) {
      myHostyPeer.inputsignal(data);
    } else {
      console.log("signal couldn't find peer");
    }
  });
}

function initiateKeyboardControls() {
  document.addEventListener("keydown", keyDownHandler);
  // initClickableKeys();
}

function keyDownHandler(event) {
  if (event.defaultPrevented) {
    return;
  }
  if (
    ["Space", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].indexOf(
      event.code
    ) > -1
  ) {
    event.preventDefault();
  }
  switch (event.code) {
    case "KeyS":
      socket.emit("fpjKeystroke", "Move backward");
      break;
    case "KeyW":
      socket.emit("fpjKeystroke", "Move forward");
      break;
    case "KeyA":
      socket.emit("fpjKeystroke", "Move left");
      break;
    case "KeyD":
      socket.emit("fpjKeystroke", "Move right");
      break;
    case "ArrowDown":
      socket.emit("fpjKeystroke", "Look down");
      break;
    case "ArrowUp":
      socket.emit("fpjKeystroke", "Look up");
      break;
    case "ArrowLeft":
      socket.emit("fpjKeystroke", "Look left");
      break;
    case "ArrowRight":
      socket.emit("fpjKeystroke", "Look right");
      break;
    case "KeyJ":
      socket.emit("fpjKeystroke", "Interact");
      break;
    case "KeyK":
      socket.emit("fpjKeystroke", "Pick up/Release item");
      break;
    case "Space":
      toggleMic();
      break;
  }
}

function toggleMic() {
  isMuted = !isMuted;
  let speakButton = document.getElementById("speak-button");
  if (isMuted) {
    speakButton.innerHTML = "📢 Push to speak 📢";
    speakButton.style.backgroundColor = "#22a737";
    console.log("muted");
  } else {
    speakButton.innerHTML = "🔇 Push to mute 🔇";
    speakButton.style.backgroundColor = "#ea4040";
    console.log("unmuted");
  }
  socket.emit("fpjMuteToggle", isMuted);
}

class SimplePeerWrapper {
  constructor(initiator, socket_id, socket, stream) {

    this.simplepeer = new SimplePeer({
      config: {
        // // uncomment to use Google servers
        //     iceServers: [
        //       { urls: "stun:stun.l.google.com:19302" },
        //       { urls: "stun:stun2.l.google.com:19302" },
        //     ],
        // // uncomment to use Metered.ca servers
        iceServers: turnServers,
      },
      initiator: initiator,
      trickle: false,
    });

    this.socket_id = socket_id;
    this.socket = socket;
    this.stream = stream;

    // simplepeer generates signals which need to be sent across socket
    this.simplepeer.on("signal", (data) => {
      console.log("emitting simplepeer signal");
      this.socket.emit("fpjSignal", this.socket_id, this.socket.id, data);
    });

    // When we have a connection, send our stream
    this.simplepeer.on("connect", () => {
      console.log("CONNECTED to Peer");
      console.log(this.simplepeer);

      // Let's give them our stream
      this.simplepeer.addStream(stream);
      console.log("Send our stream");
    });

    // Stream coming in to us
    this.simplepeer.on("stream", (stream) => {
      console.log("Incoming Stream");
      let hostyCam = document.getElementById("hostyCam");
      if ("srcObject" in hostyCam) {
        hostyCam.srcObject = stream;
      } else {
        hostyCam.src = window.URL.createObjectURL(stream); // for older browsers
      }
      hostyCam.onloadedmetadata = function (e) {
        hostyCam.play();
      };
      // console.log(hostyCam.srcObject);
    });

    this.simplepeer.on("close", () => {
      console.log("Got close event");
      window.location.replace("/fpj/");
    });

    this.simplepeer.on("error", (err) => {
      console.log(err);
    });
  }

  inputsignal(sig) {
    this.simplepeer.signal(sig);
  }
}
